# 11 Tutorial Developers

**Project:** IDM_VTON
**Upstream:** https://github.com/yisol/IDM-VTON

Content specific to IDM_VTON in category CLOTHING_RETAIL.
